
// Start aktuelle Jahreszahl
var aktuellesJahr = (new Date).getFullYear();

$(function () {
	$('#jahr').text(aktuellesJahr);
});
// Ende aktuelle Jahreszahl


