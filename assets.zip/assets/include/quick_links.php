<!-- Quicklinks -->
<div class="container header_d3">
    <div class="row">
        <div class="col-md-4">
            <div class="kasten">
                <h3>Quick Links</h3>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="community.php">Community</a></li>
                    <li><a href="pro.php">Professinal</a></li>
                    <li><a href="enterprise.php">Enterprise</a></li>
                    </br>
                </ul>
            </div>
        </div>
        <div class="col-md-4">
            <div class="kasten">
                <h3>Follow Us:</h3>
                <ul>
                    <li><a href="https://sourceforge.net/projects/faktura2018/" target="_blank">SourceForge</a></li>
                    <li><a href=" https://www.pro-linux.de/cgi-bin/DBApp/check.cgi?ShowApp..20988.100" target="_blank">Pro-Linux
                        </a> </li>
                    <li><a href=" https://wiki.ubuntuusers.de/ERP/#FAKTURA2018" target="_blank">Ubuntu User</a></li>
                    <li><a href="https://www.youtube.com/channel/UC3EGNpTOy4YvpAWpyGuAg3A/featured" target="_blank">Youtube
                            Info</a></li>
                    <li><a href="https://www.faktura123.de" target="_blank">Faktura Blog</a></li>
                </ul>
            </div>
        </div>
        <div class="col-md-4">
            <div class="kasten">
                <h3>verwendete Begriffe:</h3>
                <ul>
                    <li><a href="https://de.wikipedia.org/wiki/Fakturierung" target="_blank">Fakturierung [wikipedia]</a>
                    </li>
                    <li><a href="https://de.wikipedia.org/wiki/Einnahmenüberschussrechnung" target="_blank">EÜR
                            [wikipedia]</a></li>
                    <li><a href="https://de.wikipedia.org/wiki/Kleinunternehmerregelung_(Deutschland)" target="_blank">Kleinunternehmer
                            [wikipedia]</a></li>
                    <li><a href="https://www.youtube.com/watch?v=CcQYjPcbCBY" target="_blank">Youtube</a></li>
                    </br>
                </ul>
            </div>
        </div>
    </div>
</div>

<br>