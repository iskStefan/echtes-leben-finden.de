<br>
<footer class="footer">
	<div class="container-fluid bg-black py-3">
		<div class="row">
			<div class="col-md-4">
				<!-- a href="../faktura2020.html">
					<span>
						<img src="images/faktura64_64.png" alt="Logo Faktura2020">
					</span>
				</a-->
			</div>
			<div class="col-md-4">
				<p class="text-white">
					<a class="text-white impressum" href="../impressum.php">Impressum</a>&nbsp;&nbsp;&nbsp;<strong>&vert;</strong>&nbsp;&nbsp;
					<a class="text-white impressum" href="../datenschutz.php">Datenschutz</a>
				</p>
				<p class="text-white creator">&copy; 2022 Chrisliche Gemeinde Marktoberdorf</p>
				<!-- p class="text-white creator">created by
					<a class="text-white creator" href="https://www.ing-buero-stefan-klemm.de" target="_blank">Ing.-Büro
						Stefan Klemm</a>
					&minus; &copy;
					<span id="jahr">2020</span>
					&minus;
				</p-->
			</div>
			<div class="col-md-2">
				<!--div class="row">
					<br>
					<a href="https://www.freelancermap.de/freelancer-verzeichnis/profile/entwicklung/160884-profil-stefan-klemm-softwareentwickler.html" target="_blank" title="Profil von Stefan Klemm auf www.freelancermap.de">
						<img src="https://www.freelancermap.de/images/widgets/button/findenSieMich.png"></a>
				</div>
				<div class="row">
					<br>
					<a href="https://www.freelance.de/Freiberufler/170628" target="_blank" title="Profil von Stefan Klemm auf www.freelance.de">
						<img src="images/freelance.png" style="margin-top: 9px;"></a>
				</div-->
			</div>
		</div>
		<!-- row -->
	</div>
	<!-- container -->
</footer>
</body>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script type="text/javascript" src="assets/js/jquery-3.4.1.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
<!-- Custom -->
<script type="text/javascript" src="assets/js/custom.js"></script>

</html>